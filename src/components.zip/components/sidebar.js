import React from "react";
import { FaUserAlt } from "react-icons/fa";
import { BiLogInCircle } from "react-icons/bi";

import './style.css'


function side(){
    return(
        <div className="side">
           <div className="var">
           <div className="icon_user"> 
                <FaUserAlt/>
            </div>

            <div className="options">
                <ul>
                    <a href=".">
                        <li>Productos</li>
                    </a>
                    <a href=".">
                        <li>Categorias</li>
                    </a>
                    <a href=".">
                        <li>Configuracion</li>
                    </a>
                    <a href=".">
                        <li>Ayuda</li>
                    </a>
                </ul>
            </div>

            <div className="out">
                <div className="boton">
                    <button>Salir <BiLogInCircle className="ico"/></button>
                </div>    
            </div>
           </div>

        </div>
    );
}
export default side;